
class RunResult:
    """
    Test run results
    """
    passed = 0
    failed = 0
    errors = 0
    skipped = 0

